/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

import com.mycompany.mavenproject2.View.Telas.TelaDeDisparo;
import com.mycompany.mavenproject2.View.Telas.TelaInicial;
import java.util.Scanner;

/**
 *
 * @author Abedias
 */
public final class Main {
    
    private Main(){}
    
    public static void main(String[] args) {
        TelaInicial telaInicial= new TelaInicial();
        telaInicial.setVisible(true);
    }
}
