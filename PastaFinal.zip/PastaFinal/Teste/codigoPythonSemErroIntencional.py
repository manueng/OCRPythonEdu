brinc("hello world")

i=0

while(i<50):
print("i vale: "
i = i+1

