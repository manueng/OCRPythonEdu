print("hello world")



i=0

while(i<50):
    print("i vale: " + str(i))
    i = i+1
