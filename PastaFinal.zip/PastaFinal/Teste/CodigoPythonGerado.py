def range_len_pattern():
a= [1, 2, 3]

0 for i in _a)):

v = a[i] ,,

